<!DOCTYPE html>
<html <?php language_attributes() ?>>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php

$LastModified_unix = strtotime(date("D, d M Y H:i:s", filectime($_SERVER['SCRIPT_FILENAME'])));
$LastModified = gmdate("D, d M Y H:i:s \G\M\T", $LastModified_unix);
$IfModifiedSince = false;

if (isset($_ENV['HTTP_IF_MODIFIED_SINCE']))
   $IfModifiedSince = strtotime(substr ($_ENV['HTTP_IF_MODIFIED_SINCE'], 5));

if (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']))
   $IfModifiedSince = strtotime(substr ($_SERVER['HTTP_IF_MODIFIED_SINCE'], 5));

if ($IfModifiedSince && $IfModifiedSince -->= $LastModified_unix) {
	header($_SERVER['SERVER_PROTOCOL'] . ' 304 Not Modified');
   exit;
}

header('Last-Modified: '. $LastModified);

?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php rel_canonical(); ?>
    <?php wp_head() ?>
    <?php the_css_blocks(); ?>
</head>
<body <?php body_class() ?> id="top">


    <?php wp_body_open() ?>
    <div class="wrapper">
        <header class="header">
        <div class="container">
            <?php $custom_logo_id = get_theme_mod( 'custom_logo' );?>
                <a href="<?php echo get_home_url(); ?>" class="header__logo"><?php
                    if( !empty( $custom_logo_id ) ) {
                        echo wp_get_attachment_image( $custom_logo_id, 'full' );
                    } else {
                        bloginfo('name');
                    } ?>
                    </a>
                    <div class="header__right">
                        <nav class="header__menu">
                            <?php
                                wp_nav_menu( [
                                'theme_location'  => 'HeadMenu',
                                'container'       => null,
                                'menu_class'      => 'header__menu-list',
                                ] );
                            ?>
                        </nav>
                        <button class="header__burger-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
            </div>
    </header>
    <main class="main <?php the_field('page_class')?>">